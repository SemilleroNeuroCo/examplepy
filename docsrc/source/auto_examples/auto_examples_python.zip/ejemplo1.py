"""
Ejemplo 1 de examplepy
=======================
"""

import examplepy.calculator as calc


print('Hola')

#%%
# Suma
# ^^^^^^^^

s = calc.suma(5,1)

print('5+1=',s)

#%%
# Multiplicacion
# ^^^^^^^^^^^^^^^^

s = calc.multiplicacion(5,1)

print('5*1=',s)

